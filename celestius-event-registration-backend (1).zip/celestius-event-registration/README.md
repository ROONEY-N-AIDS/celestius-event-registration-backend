# Celestius Event Registration Backend

A RESTful backend system built with **Java 17**, **Spring Boot 3**, and **MySQL** for the **Celestius Backend Team Recruitment Task**.

## Event Overview

| Field | Value |
| :--- | :--- |
| **Event Name** | Backend Development Workshop |
| **Event Date** | 20 October 2026 |
| **Maximum Capacity** | 50 participants |

## Tech Stack

- **Language & Runtime**: Java 17
- **Framework**: Spring Boot 3.2.5 (`spring-boot-starter-web`, `spring-boot-starter-data-jpa`, `spring-boot-starter-validation`)
- **Database**: MySQL 8.x (`mysql-connector-j`)
- **Testing**: JUnit 5, Spring MockMvc, Mockito (`spring-boot-starter-test`)
- **Build Tool**: Apache Maven

## Project Structure

```text
celestius-event-registration/
├── pom.xml
├── README.md
└── src/
    ├── main/
    │   ├── java/com/celestius/registration/
    │   │   ├── EventRegistrationApplication.java
    │   │   ├── controller/
    │   │   │   └── RegistrationController.java
    │   │   ├── model/
    │   │   │   └── Registration.java
    │   │   ├── repository/
    │   │   │   └── RegistrationRepository.java
    │   │   └── service/
    │   │       └── RegistrationService.java
    │   └── resources/
    │       ├── application.properties
    │       └── schema.sql
    └── test/
        └── java/com/celestius/registration/
            └── RegistrationControllerTest.java
```

## Setup & Installation

### 1. Prerequisites

- **Java 17** or newer installed (`java -version`)
- **Maven 3.8+** installed (`mvn -version`)
- **MySQL Server 8.0+** running locally on port `3306`

### 2. Configure MySQL

By default, `application.properties` connects to `jdbc:mysql://localhost:3306/celestius_events` with `createDatabaseIfNotExist=true` and Hibernate `ddl-auto=update`.

Update your MySQL credentials in `src/main/resources/application.properties` if needed:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/celestius_events?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=your_mysql_password
```

Alternatively, you can initialize the database manually using the included SQL script:

```bash
mysql -u root -p < src/main/resources/schema.sql
```

### 3. Build & Run the Application

```bash
mvn clean spring-boot:run
```

The server starts at `http://localhost:8080`.

### 4. Run Automated Tests

```bash
mvn test
```

## API Reference

### 1. Register for the Event (`POST /register`)

Registers a student for the **Backend Development Workshop**. Automatically records `registrationTime` and enforces both duplicate-email prevention and the 50-participant capacity limit.

**Request**

```bash
curl -X POST http://localhost:8080/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Aarav Sharma",
    "email": "aarav.sharma@college.edu",
    "collegeDepartment": "Computer Science"
  }'
```

*(Note: `collegeDepartment` is optional and also accepts `college_department`, `college`, or `department` as JSON keys.)*

**Responses**

| Scenario | HTTP Status | Sample Response Body |
| :--- | :--- | :--- |
| **Successful Registration** | `201 Created` | `{"status": "success", "message": "Registration successful for Backend Development Workshop", "registration": {"id": 1, "name": "Aarav Sharma", "email": "aarav.sharma@college.edu", "collegeDepartment": "Computer Science", "registrationTime": "2026-10-15T10:30:00"}}` |
| **Event Capacity Reached (50/50)** | `400 Bad Request` | `{"status": 400, "error": "Bad Request", "message": "Event is full"}` |
| **Duplicate Email Registration** | `409 Conflict` | `{"status": 409, "error": "Conflict", "message": "A participant with email 'aarav.sharma@college.edu' is already registered for this event."}` |
| **Missing / Invalid Fields** | `400 Bad Request` | `{"status": 400, "error": "Bad Request", "message": "Invalid or missing registration information", "validationErrors": {"name": "Name is required and cannot be blank", "email": "Please provide a valid email address"}}` |

### 2. View All Registrations (`GET /registrations`)

Retrieves event capacity metrics (`registeredCount`, `availableSeats`, `seatsStatus`) along with the full list of registered participants.

**Request**

```bash
curl -X GET http://localhost:8080/registrations
```

**Response (`200 OK`)**

```json
{
  "event": "Backend Development Workshop",
  "date": "20 October 2026",
  "capacity": 50,
  "registeredCount": 1,
  "availableSeats": 49,
  "seatsStatus": "1 / 50 seats filled",
  "registrations": [
    {
      "id": 1,
      "name": "Aarav Sharma",
      "email": "aarav.sharma@college.edu",
      "collegeDepartment": "Computer Science",
      "registrationTime": "2026-10-15T10:30:00"
    }
  ]
}
```

### 3. View a Single Registration (`GET /registrations/{identifier}`)

Retrieves a participant's registration using **either** their numeric registration ID or their email address.

**Lookup by Registration ID**

```bash
curl -X GET http://localhost:8080/registrations/1
```

**Lookup by Email Address**

```bash
curl -X GET http://localhost:8080/registrations/aarav.sharma@college.edu
```

**Responses**

| Scenario | HTTP Status | Sample Response Body |
| :--- | :--- | :--- |
| **Participant Found** | `200 OK` | `{"id": 1, "name": "Aarav Sharma", "email": "aarav.sharma@college.edu", "collegeDepartment": "Computer Science", "registrationTime": "2026-10-15T10:30:00"}` |
| **Participant Not Found** | `404 Not Found` | `{"status": 404, "error": "Not Found", "message": "Registration not found with ID: 999"}` |

## Key Design Decisions

1. **Layered Architecture**: Separated into Controller (`RegistrationController`), Service (`RegistrationService`), Repository (`RegistrationRepository`), and Entity (`Registration`) layers so HTTP routing, business rules, and MySQL persistence stay decoupled.
2. **Concurrency-Safe Capacity Enforcement**: `registerParticipant` is annotated with `@Transactional` and `synchronized` so concurrent requests when 49/50 seats are filled cannot bypass the 50-seat limit, and the unique constraint `uk_registrations_email` on the MySQL `email` column guarantees database-level integrity.
3. **Dual Identifier Resolution**: `GET /registrations/{identifier:.+}` uses a path-variable regex to preserve dots in email addresses and inspects whether `{identifier}` is numeric (`^\d+$`) to route to `findById(Long)` or `findByEmailIgnoreCase(String)`.
