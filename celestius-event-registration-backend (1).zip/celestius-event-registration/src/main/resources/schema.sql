-- ===================================================================
-- MySQL Schema for Celestius Event Registration System
-- Event: Backend Development Workshop | Date: 20 October 2026
-- ===================================================================

CREATE DATABASE IF NOT EXISTS celestius_events
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE celestius_events;

CREATE TABLE IF NOT EXISTS registrations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(180) NOT NULL UNIQUE,
    college_department VARCHAR(200) DEFAULT NULL,
    registration_time DATETIME(6) NOT NULL,
    INDEX idx_registrations_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
