package com.celestius.registration.controller;

import com.celestius.registration.model.Registration;
import com.celestius.registration.service.RegistrationService;
import com.celestius.registration.service.RegistrationService.DuplicateRegistrationException;
import com.celestius.registration.service.RegistrationService.EventFullException;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@RestController
public class RegistrationController {

    private final RegistrationService registrationService;

    public RegistrationController(RegistrationService registrationService) {
        this.registrationService = registrationService;
    }

    /**
     * 1. Register for the Event
     * Endpoint: POST /register
     */
    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> registerForEvent(
            @Valid @RequestBody Registration request) {

        Registration saved = registrationService.registerParticipant(request);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("status", "success");
        response.put("message", "Registration successful for " + registrationService.getEventName());
        response.put("registration", saved);

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * 2. View All Registrations
     * Endpoint: GET /registrations
     */
    @GetMapping("/registrations")
    public ResponseEntity<Map<String, Object>> getAllRegistrations() {
        List<Registration> registrations = registrationService.getAllRegistrations();
        int capacity = registrationService.getMaxCapacity();
        int registeredCount = registrations.size();

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("event", registrationService.getEventName());
        response.put("date", registrationService.getEventDate());
        response.put("capacity", capacity);
        response.put("registeredCount", registeredCount);
        response.put("availableSeats", Math.max(0, capacity - registeredCount));
        response.put("seatsStatus", registeredCount + " / " + capacity + " seats filled");
        response.put("registrations", registrations);

        return ResponseEntity.ok(response);
    }

    /**
     * 3. View a Single Registration (Supports lookup by numeric ID or email address)
     * Endpoint: GET /registrations/{identifier}
     * Regex '{identifier:.+}' preserves dots in email addresses (e.g., student@college.edu)
     */
    @GetMapping("/registrations/{identifier:.+}")
    public ResponseEntity<Registration> getSingleRegistration(
            @PathVariable("identifier") String identifier) {

        Registration registration = registrationService.getRegistrationByIdentifier(identifier);
        return ResponseEntity.ok(registration);
    }

    // ===================================================================
    // Exception Handlers for Clear, Consistent API Error Responses
    // ===================================================================

    @ExceptionHandler(EventFullException.class)
    public ResponseEntity<Map<String, Object>> handleEventFull(EventFullException ex) {
        return buildErrorResponse(HttpStatus.BAD_REQUEST, ex.getMessage(), null);
    }

    @ExceptionHandler(DuplicateRegistrationException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateRegistration(DuplicateRegistrationException ex) {
        return buildErrorResponse(HttpStatus.CONFLICT, ex.getMessage(), null);
    }

    @ExceptionHandler(NoSuchElementException.class)
    public ResponseEntity<Map<String, Object>> handleNotFound(NoSuchElementException ex) {
        return buildErrorResponse(HttpStatus.NOT_FOUND, ex.getMessage(), null);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationErrors(MethodArgumentNotValidException ex) {
        Map<String, String> fieldErrors = new LinkedHashMap<>();
        for (FieldError fieldError : ex.getBindingResult().getFieldErrors()) {
            fieldErrors.put(fieldError.getField(), fieldError.getDefaultMessage());
        }
        return buildErrorResponse(
                HttpStatus.BAD_REQUEST,
                "Invalid or missing registration information",
                fieldErrors
        );
    }

    @ExceptionHandler({IllegalArgumentException.class, HttpMessageNotReadableException.class})
    public ResponseEntity<Map<String, Object>> handleBadRequest(Exception ex) {
        return buildErrorResponse(
                HttpStatus.BAD_REQUEST,
                "Invalid request payload: " + ex.getMessage(),
                null
        );
    }

    private ResponseEntity<Map<String, Object>> buildErrorResponse(
            HttpStatus status, String message, Map<String, String> errors) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now().toString());
        body.put("status", status.value());
        body.put("error", status.getReasonPhrase());
        body.put("message", message);
        if (errors != null && !errors.isEmpty()) {
            body.put("validationErrors", errors);
        }
        return ResponseEntity.status(status).body(body);
    }
}
