package com.celestius.registration.repository;

import com.celestius.registration.model.Registration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RegistrationRepository extends JpaRepository<Registration, Long> {

    /**
     * Checks whether a participant with the given email is already registered (case-insensitive).
     */
    boolean existsByEmailIgnoreCase(String email);

    /**
     * Finds a registration by participant email address (case-insensitive).
     */
    Optional<Registration> findByEmailIgnoreCase(String email);
}
