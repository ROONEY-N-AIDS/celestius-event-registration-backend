package com.celestius.registration.service;

import com.celestius.registration.model.Registration;
import com.celestius.registration.repository.RegistrationRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class RegistrationService {

    private final RegistrationRepository registrationRepository;
    private final int maxCapacity;
    private final String eventName;
    private final String eventDate;

    public RegistrationService(
            RegistrationRepository registrationRepository,
            @Value("${event.capacity:50}") int maxCapacity,
            @Value("${event.name:Backend Development Workshop}") String eventName,
            @Value("${event.date:20 October 2026}") String eventDate) {
        this.registrationRepository = registrationRepository;
        this.maxCapacity = maxCapacity;
        this.eventName = eventName;
        this.eventDate = eventDate;
    }

    /**
     * Registers a student for the Backend Development Workshop.
     * Synchronized and transactional to prevent race conditions when capacity approaches 50.
     */
    @Transactional
    public synchronized Registration registerParticipant(Registration request) {
        String normalizedEmail = request.getEmail().trim().toLowerCase();

        // 1. Check for duplicate email registration before checking or consuming capacity
        if (registrationRepository.existsByEmailIgnoreCase(normalizedEmail)) {
            throw new DuplicateRegistrationException(
                    "A participant with email '" + normalizedEmail + "' is already registered for this event."
            );
        }

        // 2. Enforce event capacity limit (50 participants)
        long currentCount = registrationRepository.count();
        if (currentCount >= maxCapacity) {
            throw new EventFullException("Event is full");
        }

        // 3. Populate metadata and persist registration
        Registration registration = new Registration(
                request.getName().trim(),
                normalizedEmail,
                request.getCollegeDepartment() != null ? request.getCollegeDepartment().trim() : null
        );
        registration.setRegistrationTime(LocalDateTime.now());

        return registrationRepository.save(registration);
    }

    /**
     * Returns all registered participants ordered by registration ID.
     */
    @Transactional(readOnly = true)
    public List<Registration> getAllRegistrations() {
        return registrationRepository.findAll();
    }

    /**
     * Retrieves a single registration by either numeric registration ID or email address.
     */
    @Transactional(readOnly = true)
    public Registration getRegistrationByIdentifier(String identifier) {
        if (identifier == null || identifier.isBlank()) {
            throw new IllegalArgumentException("Registration identifier (ID or email) must not be empty.");
        }

        String trimmed = identifier.trim();

        // If the identifier consists strictly of digits, look up by numeric primary key ID
        if (trimmed.matches("^\\d+$")) {
            Long id = Long.parseLong(trimmed);
            return registrationRepository.findById(id)
                    .orElseThrow(() -> new NoSuchElementException(
                            "Registration not found with ID: " + id
                    ));
        }

        // Otherwise, treat the identifier as an email address
        return registrationRepository.findByEmailIgnoreCase(trimmed)
                .orElseThrow(() -> new NoSuchElementException(
                        "Registration not found with email: " + trimmed
                ));
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    public String getEventName() {
        return eventName;
    }

    public String getEventDate() {
        return eventDate;
    }

    // Custom domain exceptions for clear HTTP status mapping
    public static class EventFullException extends RuntimeException {
        public EventFullException(String message) {
            super(message);
        }
    }

    public static class DuplicateRegistrationException extends RuntimeException {
        public DuplicateRegistrationException(String message) {
            super(message);
        }
    }
}
