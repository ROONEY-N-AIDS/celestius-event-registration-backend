package com.celestius.registration.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

@Entity
@Table(
    name = "registrations",
    uniqueConstraints = {
        @UniqueConstraint(name = "uk_registrations_email", columnNames = "email")
    }
)
public class Registration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;

    @NotBlank(message = "Name is required and cannot be blank")
    @Size(max = 120, message = "Name must not exceed 120 characters")
    @Column(name = "name", nullable = false, length = 120)
    private String name;

    @NotBlank(message = "Email is required and cannot be blank")
    @Email(message = "Please provide a valid email address")
    @Size(max = 180, message = "Email must not exceed 180 characters")
    @Column(name = "email", nullable = false, unique = true, length = 180)
    private String email;

    @Size(max = 200, message = "College / Department must not exceed 200 characters")
    @JsonAlias({"college_department", "college", "department"})
    @Column(name = "college_department", length = 200)
    private String collegeDepartment;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @Column(name = "registration_time", nullable = false, updatable = false)
    private LocalDateTime registrationTime;

    public Registration() {
    }

    public Registration(String name, String email, String collegeDepartment) {
        this.name = name;
        this.email = email;
        this.collegeDepartment = collegeDepartment;
    }

    @PrePersist
    protected void onCreate() {
        if (this.registrationTime == null) {
            this.registrationTime = LocalDateTime.now();
        }
        if (this.email != null) {
            this.email = this.email.trim().toLowerCase();
        }
        if (this.name != null) {
            this.name = this.name.trim();
        }
        if (this.collegeDepartment != null) {
            this.collegeDepartment = this.collegeDepartment.trim();
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCollegeDepartment() {
        return collegeDepartment;
    }

    public void setCollegeDepartment(String collegeDepartment) {
        this.collegeDepartment = collegeDepartment;
    }

    public LocalDateTime getRegistrationTime() {
        return registrationTime;
    }

    public void setRegistrationTime(LocalDateTime registrationTime) {
        this.registrationTime = registrationTime;
    }
}
