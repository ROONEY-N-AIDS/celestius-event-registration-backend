package com.celestius.registration;

import com.celestius.registration.controller.RegistrationController;
import com.celestius.registration.model.Registration;
import com.celestius.registration.repository.RegistrationRepository;
import com.celestius.registration.service.RegistrationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(RegistrationController.class)
@Import(RegistrationService.class)
class RegistrationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private RegistrationRepository registrationRepository;

    private Registration sampleRegistration;

    @BeforeEach
    void setUp() {
        sampleRegistration = new Registration("Aarav Sharma", "aarav.sharma@college.edu", "Computer Science");
        sampleRegistration.setId(1L);
        sampleRegistration.setRegistrationTime(LocalDateTime.of(2026, 10, 15, 10, 30, 0));
    }

    @Test
    @DisplayName("1. POST /register - Successful registration returns 201 Created")
    void shouldRegisterParticipantSuccessfully() throws Exception {
        when(registrationRepository.existsByEmailIgnoreCase("aarav.sharma@college.edu")).thenReturn(false);
        when(registrationRepository.count()).thenReturn(10L);
        when(registrationRepository.save(any(Registration.class))).thenReturn(sampleRegistration);

        Map<String, String> payload = Map.of(
                "name", "Aarav Sharma",
                "email", "aarav.sharma@college.edu",
                "collegeDepartment", "Computer Science"
        );

        mockMvc.perform(post("/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.registration.id").value(1))
                .andExpect(jsonPath("$.registration.name").value("Aarav Sharma"))
                .andExpect(jsonPath("$.registration.email").value("aarav.sharma@college.edu"))
                .andExpect(jsonPath("$.registration.collegeDepartment").value("Computer Science"));
    }

    @Test
    @DisplayName("2. POST /register - Rejects registration when event capacity (50) is reached")
    void shouldRejectWhenEventCapacityReached() throws Exception {
        when(registrationRepository.existsByEmailIgnoreCase("new.student@college.edu")).thenReturn(false);
        when(registrationRepository.count()).thenReturn(50L);

        Map<String, String> payload = Map.of(
                "name", "New Student",
                "email", "new.student@college.edu",
                "collegeDepartment", "Information Technology"
        );

        mockMvc.perform(post("/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Event is full"));
    }

    @Test
    @DisplayName("3. POST /register - Rejects duplicate email registration with 409 Conflict")
    void shouldRejectDuplicateEmailRegistration() throws Exception {
        when(registrationRepository.existsByEmailIgnoreCase("aarav.sharma@college.edu")).thenReturn(true);

        Map<String, String> payload = Map.of(
                "name", "Aarav Sharma",
                "email", "aarav.sharma@college.edu"
        );

        mockMvc.perform(post("/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.error").value("Conflict"));
    }

    @Test
    @DisplayName("4. POST /register - Rejects invalid or missing fields with 400 Bad Request")
    void shouldRejectInvalidOrMissingInformation() throws Exception {
        Map<String, String> invalidPayload = Map.of(
                "name", "",
                "email", "not-an-email"
        );

        mockMvc.perform(post("/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidPayload)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Invalid or missing registration information"))
                .andExpect(jsonPath("$.validationErrors.name").exists())
                .andExpect(jsonPath("$.validationErrors.email").exists());
    }

    @Test
    @DisplayName("5. GET /registrations - Returns all registrations and seat counts")
    void shouldReturnAllRegistrations() throws Exception {
        when(registrationRepository.findAll()).thenReturn(List.of(sampleRegistration));

        mockMvc.perform(get("/registrations"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.event").value("Backend Development Workshop"))
                .andExpect(jsonPath("$.capacity").value(50))
                .andExpect(jsonPath("$.registeredCount").value(1))
                .andExpect(jsonPath("$.availableSeats").value(49))
                .andExpect(jsonPath("$.seatsStatus").value("1 / 50 seats filled"))
                .andExpect(jsonPath("$.registrations[0].email").value("aarav.sharma@college.edu"));
    }

    @Test
    @DisplayName("6. GET /registrations/{id} - Retrieves single registration by numeric ID")
    void shouldGetSingleRegistrationById() throws Exception {
        when(registrationRepository.findById(1L)).thenReturn(Optional.of(sampleRegistration));

        mockMvc.perform(get("/registrations/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.name").value("Aarav Sharma"));
    }

    @Test
    @DisplayName("7. GET /registrations/{email} - Retrieves single registration by email address")
    void shouldGetSingleRegistrationByEmail() throws Exception {
        when(registrationRepository.findByEmailIgnoreCase("aarav.sharma@college.edu"))
                .thenReturn(Optional.of(sampleRegistration));

        mockMvc.perform(get("/registrations/aarav.sharma@college.edu"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.email").value("aarav.sharma@college.edu"));
    }

    @Test
    @DisplayName("8. GET /registrations/{identifier} - Returns 404 Not Found when registration does not exist")
    void shouldReturn404WhenRegistrationNotFound() throws Exception {
        when(registrationRepository.findById(999L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/registrations/999"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Registration not found with ID: 999"));
    }
}
